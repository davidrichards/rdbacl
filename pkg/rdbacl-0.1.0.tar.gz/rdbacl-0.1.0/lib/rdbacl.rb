require 'rubygems'
Dir.glob("#{File.dirname(__FILE__)}/rdbacl/*.rb").each { |file| require file }

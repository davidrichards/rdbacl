# This gem's Jekyl is a Rails plugin.  Here, we define how ActiveRecord
# should have a creates_a_dbacl macro and how the rdbacl code gets used
# on a model. 
puts 'aaaaaaaaaaaaaaaaaaaaa'

FIND_ME = 1